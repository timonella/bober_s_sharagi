﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDF_Reader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            MenuStrip menuStrip = new MenuStrip();
            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);

            ToolStripMenuItem fileMenuItem = new ToolStripMenuItem("File");

            ToolStripMenuItem openMenuItem = new ToolStripMenuItem("Open");
            openMenuItem.Click += OpenMenuItem_Click;
            fileMenuItem.DropDownItems.Add(openMenuItem);

            ToolStripMenuItem exitMenuItem = new ToolStripMenuItem("Exit");
            exitMenuItem.Click += ExitMenuItem_Click;
            fileMenuItem.DropDownItems.Add(exitMenuItem);

            menuStrip.Items.Add(fileMenuItem);
        }

        private void OpenMenuItem_Click(object sender, EventArgs e)
        {

            openFileDialog1.Filter = "Файлы pdf|*.pdf";
            openFileDialog1.ShowDialog();
            axAcroPDF1.LoadFile(openFileDialog1.FileName);
            axAcroPDF1.Show();

        }

        private void ExitMenuItem_Click(object sender, EventArgs e)
        {
            axAcroPDF1.Hide();
        }

    }
}
